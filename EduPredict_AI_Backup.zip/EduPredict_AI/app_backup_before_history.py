from pathlib import Path
import json

import joblib
import pandas as pd
from flask import Flask, render_template, request


ROOT = Path(__file__).resolve().parent

app = Flask(
    __name__,
    template_folder=str(ROOT / "app" / "templates"),
    static_folder=str(ROOT / "app" / "static"),
)

GRADE_MODEL_PATH = ROOT / "models" / "uci_best_grade_model.joblib"
RISK_MODEL_PATH = ROOT / "models" / "uci_best_risk_model.joblib"
REPORT_DIR = ROOT / "reports"

grade_model = joblib.load(GRADE_MODEL_PATH)
risk_model = joblib.load(RISK_MODEL_PATH)


# Load the original dataset to obtain the exact feature names
# and valid choices used by the trained models.
DATASET_PATH = (
    ROOT
    / "data"
    / "external"
    / "uci_student_performance"
    / "extracted"
    / "student-mat.csv"
)

dataset = pd.read_csv(DATASET_PATH, sep=";")

RISK_FEATURES = [
    column for column in dataset.columns
    if column not in ["G1", "G2", "G3"]
]

GRADE_FEATURES = [
    column for column in dataset.columns
    if column not in ["G1", "G2", "G3"]
]


def get_feature_metadata():
    metadata = []

    for column in RISK_FEATURES:
        if pd.api.types.is_numeric_dtype(dataset[column]):
            metadata.append({
                "name": column,
                "type": "number",
                "minimum": float(dataset[column].min()),
                "maximum": float(dataset[column].max()),
                "default": float(dataset[column].median()),
                "choices": [],
            })
        else:
            choices = sorted(
                dataset[column].dropna().astype(str).unique().tolist()
            )

            metadata.append({
                "name": column,
                "type": "select",
                "minimum": None,
                "maximum": None,
                "default": choices[0] if choices else "",
                "choices": choices,
            })

    return metadata


FEATURE_METADATA = get_feature_metadata()


def create_input_dataframe(form_data):
    values = {}

    for feature in RISK_FEATURES:
        raw_value = form_data.get(feature, "").strip()

        if raw_value == "":
            raise ValueError(
                f"Please provide a value for {feature}."
            )

        if pd.api.types.is_numeric_dtype(dataset[feature]):
            value = float(raw_value)

            minimum = float(dataset[feature].min())
            maximum = float(dataset[feature].max())

            if value < minimum or value > maximum:
                raise ValueError(
                    f"{feature} must be between "
                    f"{minimum:g} and {maximum:g}."
                )

            # Most numerical fields in this dataset represent
            # integer counts or integer-coded categories.
            if pd.api.types.is_integer_dtype(dataset[feature]):
                if not value.is_integer():
                    raise ValueError(
                        f"{feature} must be a whole number."
                    )
                value = int(value)

            values[feature] = value

        else:
            valid_choices = (
                dataset[feature].dropna().astype(str).unique().tolist()
            )

            if raw_value not in valid_choices:
                raise ValueError(
                    f"Invalid choice for {feature}."
                )

            values[feature] = raw_value

    return pd.DataFrame([values], columns=RISK_FEATURES)


def load_json_report(filename):
    path = REPORT_DIR / filename

    if not path.exists():
        return {}

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


@app.route("/")
def home():
    grade_summary = load_json_report(
        "uci_best_model_summary.json"
    )
    risk_summary = load_json_report(
        "uci_best_risk_model_summary.json"
    )

    return render_template(
        "index.html",
        total_students=len(dataset),
        grade_model=grade_summary,
        risk_model=risk_summary,
    )


@app.route("/predict", methods=["GET", "POST"])
def predict():
    result = None
    error = None
    form_values = {}

    if request.method == "POST":
        form_values = request.form.to_dict()

        try:
            student_data = create_input_dataframe(request.form)

            grade_prediction = float(
                grade_model.predict(student_data)[0]
            )

            grade_prediction = max(0.0, min(20.0, grade_prediction))

            risk_prediction = int(
                risk_model.predict(student_data)[0]
            )

            risk_probability = None

            if hasattr(risk_model, "predict_proba"):
                classes = list(risk_model.classes_)

                if 1 in classes:
                    risk_probability = float(
                        risk_model.predict_proba(student_data)[0][
                            classes.index(1)
                        ]
                    )

            result = {
                "grade": round(grade_prediction, 2),
                "risk": (
                    "At Risk"
                    if risk_prediction == 1
                    else "Not At Risk"
                ),
                "risk_probability": (
                    round(risk_probability * 100, 2)
                    if risk_probability is not None
                    else None
                ),
            }

        except (ValueError, TypeError) as exc:
            error = str(exc)

        except Exception:
            app.logger.exception("Prediction failed")
            error = (
                "Prediction could not be completed. "
                "Please check the supplied values."
            )

    return render_template(
        "predict.html",
        features=FEATURE_METADATA,
        result=result,
        error=error,
        form_values=form_values,
    )


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/health")
def health():
    return {
        "status": "ok",
        "application": "EduPredict AI",
        "grade_model_loaded": grade_model is not None,
        "risk_model_loaded": risk_model is not None,
    }




@app.route("/analytics")
def analytics():
    import plotly.graph_objects as go
    from plotly.utils import PlotlyJSONEncoder

    # Read the existing model evaluation reports.
    regression = pd.read_csv(
        REPORT_DIR / "uci_model_comparison.csv"
    )
    classification = pd.read_csv(
        REPORT_DIR / "uci_risk_model_comparison.csv"
    )
    importance = pd.read_csv(
        REPORT_DIR / "uci_risk_permutation_importance.csv"
    )

    # Calculate dataset-level risk distribution from the original data.
    grades = pd.to_numeric(dataset["G3"], errors="coerce").dropna()
    risk_labels = grades < 10
    at_risk_count = int(risk_labels.sum())
    total_students = int(len(grades))
    at_risk_percent = (
        round(at_risk_count / total_students * 100, 1)
        if total_students else 0
    )

    # Find the selected grade model using the saved model comparison.
    grade_row = regression.loc[
        regression["Model"].eq("Random Forest")
    ]
    if grade_row.empty:
        grade_row = regression.sort_values("CV_MAE").head(1)

    grade_mae = float(grade_row.iloc[0]["Test_MAE"])

    # The risk classifier was selected by cross-validation F1.
    eligible_models = classification[
        classification["Model"].ne("Dummy Baseline")
    ]
    selected_row = eligible_models.sort_values(
        "CV_F1", ascending=False
    ).iloc[0]

    risk_recall = float(selected_row["Test_Recall"]) * 100
    risk_auc = float(selected_row["Test_ROC_AUC"])

    def figure_payload(figure):
        return figure.to_plotly_json()

    charts = {}

    # 1. Student risk distribution.
    charts["risk"] = figure_payload(
        go.Figure(
            data=[
                go.Pie(
                    labels=["At Risk", "Not At Risk"],
                    values=[
                        at_risk_count,
                        total_students - at_risk_count,
                    ],
                    hole=0.55,
                    textinfo="label+percent",
                    hovertemplate="%{label}: %{value} students<extra></extra>",
                )
            ],
            layout=go.Layout(
                title="Students by project-defined risk label",
                showlegend=True,
            ),
        )
    )

    # 2. Final grade distribution.
    charts["grade"] = figure_payload(
        go.Figure(
            data=[
                go.Histogram(
                    x=grades.tolist(),
                    xbins={"start": 0, "end": 21, "size": 1},
                    name="Students",
                    hovertemplate="Grade: %{x}<br>Students: %{y}<extra></extra>",
                )
            ],
            layout=go.Layout(
                xaxis_title="Final grade (G3)",
                yaxis_title="Number of students",
                bargap=0.08,
            ),
        )
    )

    # 3. Regression model comparison by test MAE.
    regression_sorted = regression.sort_values("Test_MAE")
    charts["regression"] = figure_payload(
        go.Figure(
            data=[
                go.Bar(
                    x=regression_sorted["Test_MAE"].tolist(),
                    y=regression_sorted["Model"].tolist(),
                    orientation="h",
                    text=regression_sorted["Test_MAE"].round(3).tolist(),
                    textposition="auto",
                    hovertemplate="%{y}<br>Test MAE: %{x:.3f}<extra></extra>",
                )
            ],
            layout=go.Layout(
                xaxis_title="Test MAE (lower is better)",
                yaxis={"autorange": "reversed"},
            ),
        )
    )

    # 4. Risk classification model comparison by test F1.
    classification_sorted = classification.sort_values("Test_F1")
    charts["classification"] = figure_payload(
        go.Figure(
            data=[
                go.Bar(
                    x=classification_sorted["Test_F1"].tolist(),
                    y=classification_sorted["Model"].tolist(),
                    orientation="h",
                    text=classification_sorted["Test_F1"].round(3).tolist(),
                    textposition="auto",
                    hovertemplate="%{y}<br>Test F1: %{x:.3f}<extra></extra>",
                )
            ],
            layout=go.Layout(
                xaxis_title="Test F1-score",
                xaxis={"range": [0, 1]},
                yaxis={"autorange": "reversed"},
            ),
        )
    )

    # 5. Top 10 permutation-importance features.
    top_importance = importance.sort_values(
        "Importance_Mean", ascending=True
    ).tail(10)

    charts["importance"] = figure_payload(
        go.Figure(
            data=[
                go.Bar(
                    x=top_importance["Importance_Mean"].tolist(),
                    y=top_importance["Feature"].tolist(),
                    orientation="h",
                    error_x={
                        "type": "data",
                        "array": top_importance["Importance_Std"].fillna(0).tolist(),
                        "visible": True,
                    },
                    hovertemplate="%{y}<br>Mean F1 decrease: %{x:.4f}<extra></extra>",
                )
            ],
            layout=go.Layout(
                xaxis_title="Mean decrease in test F1",
                yaxis={"autorange": "reversed"},
            ),
        )
    )

    # 6. Evaluation metrics for the selected risk classifier.
    metric_names = ["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]
    metric_columns = [
        "Test_Accuracy",
        "Test_Precision",
        "Test_Recall",
        "Test_F1",
        "Test_ROC_AUC",
    ]
    metric_values = [
        float(selected_row[column]) for column in metric_columns
    ]

    charts["evaluation"] = figure_payload(
        go.Figure(
            data=[
                go.Bar(
                    x=metric_names,
                    y=metric_values,
                    text=[f"{value:.3f}" for value in metric_values],
                    textposition="auto",
                    hovertemplate="%{x}: %{y:.3f}<extra></extra>",
                )
            ],
            layout=go.Layout(
                yaxis_title="Score",
                yaxis={"range": [0, 1]},
            ),
        )
    )

    charts_json = json.dumps(charts, cls=PlotlyJSONEncoder)

    return render_template(
        "analytics.html",
        total_students=total_students,
        at_risk_count=at_risk_count,
        at_risk_percent=at_risk_percent,
        grade_mae=f"{grade_mae:.3f}",
        risk_recall=f"{risk_recall:.1f}",
        risk_auc=f"{risk_auc:.3f}",
        charts_json=charts_json,
    )


if __name__ == "__main__":
    app.run(debug=True)
